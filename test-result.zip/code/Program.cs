// App setup.
var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

// GET /api/hello responds with "Hello, world!".
app.MapGet(
    "/api/hello",
    () =>
    {
        return Results.Text("Hello, world!");
    }
);

app.Run();

// Functional test project can test app in-memory.
public partial class Program { }
