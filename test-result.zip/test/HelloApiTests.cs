using Microsoft.AspNetCore.Mvc.Testing;

namespace SystemApp.SystemFunctionalTests;

public class HelloApiTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> factory;

    public HelloApiTests(WebApplicationFactory<Program> factory)
    {
        this.factory = factory;
    }

    // TC-001: GET /api/hello returns the text "Hello, world!".
    [Fact]
    public async Task GetHello_ReturnsHelloWorldText_WhenCalled()
    {
        // Make a fresh client, so this test shares nothing.
        var client = factory.CreateClient();

        // Step 01: send GET request to /api/hello.
        var response = await client.GetAsync("/api/hello", TestContext.Current.CancellationToken);
        var body = await response.Content.ReadAsStringAsync(TestContext.Current.CancellationToken);

        // Expected result: body text equals "Hello, world!".
        Assert.Equal("Hello, world!", body);
    }
}
